package com.miniprojecttwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniProjectTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniProjectTwoApplication.class, args);
	}

}
