package com.miniprojecttwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniProjectTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
